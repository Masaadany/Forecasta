# Forecasta Next.js Starter Package

## What is included
- Next.js App Router starter
- Futuristic dark visual system
- 3D globe-style hero placeholder
- Page architecture for all major Forecasta modules
- Mock data and starter API routes
- Prisma schema starter
- Product scaffolding aligned to Forecasta PRD

## Recommended next steps
1. Install dependencies: `npm install`
2. Run locally: `npm run dev`
3. Replace mock data with real connectors and services.
4. Add authentication, billing, and role-based access.
5. Upgrade globe placeholder to React Three Fiber and real geospatial layers.
6. Add charting, advanced filters, and export services.

## Notes
This package is intentionally production-oriented in structure but demo-oriented in data. It is designed to help you start fast with strong architecture and premium presentation.
