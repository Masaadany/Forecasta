export const mainNavigation = [
  ['/', 'Home'],
  ['/dashboard', 'Dashboard'],
  ['/countries/united-arab-emirates', 'Countries'],
  ['/sectors/advanced-manufacturing', 'Sectors'],
  ['/companies/global-logix', 'Companies'],
  ['/opportunities', 'Opportunities Map'],
  ['/benchmarking', 'Benchmarking'],
  ['/forecasts', 'Forecasts'],
  ['/publications', 'Publications'],
  ['/advisory', 'Advisory']
] as const;
