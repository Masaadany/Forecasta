import type { Company, Country, Kpi, Policy, Publication, Sector } from '@/lib/types';

export const headlineKpis: Kpi[] = [
  { label: 'Tracked Economies', value: '190+', change: '+12 new feeds', source: 'Forecasta Source Registry', updatedAt: '2026-03-08' },
  { label: 'Indicators', value: '3,200+', change: '+84 refreshed today', source: 'Official + monitored feeds', updatedAt: '2026-03-08' },
  { label: 'Policies & Incentives', value: '18,500+', change: '+29 monitored changes', source: 'Policy intelligence engine', updatedAt: '2026-03-08' },
  { label: 'Publications Indexed', value: '52,000+', change: '+143 new documents', source: 'Publication observatory', updatedAt: '2026-03-08' }
];

export const countries: Country[] = [
  {
    slug: 'united-arab-emirates',
    name: 'United Arab Emirates',
    region: 'Middle East',
    capital: 'Abu Dhabi',
    flag: '🇦🇪',
    summary: 'A global gateway economy with strong logistics, clean energy, advanced industry, digital economy, and investment competitiveness positioning.',
    strengths: ['Logistics & trade connectivity', 'Advanced manufacturing', 'Renewables & energy transition', 'Digital economy & AI'],
    metrics: [
      { label: 'Investment Attractiveness', value: '92/100', change: '+3.4 YoY', source: 'Forecasta composite', updatedAt: '2026-03-08' },
      { label: 'Trade Momentum', value: '+8.2%', change: '12M growth', source: 'Trade monitor', updatedAt: '2026-03-08' },
      { label: 'Policy Agility', value: 'High', change: '3 reforms tracked', source: 'Policy tracker', updatedAt: '2026-03-08' }
    ]
  },
  {
    slug: 'saudi-arabia',
    name: 'Saudi Arabia',
    region: 'Middle East',
    capital: 'Riyadh',
    flag: '🇸🇦',
    summary: 'A scale market undergoing major transformation through industrial, tourism, logistics, and investment reforms.',
    strengths: ['Mega-project pipeline', 'Industrial strategy', 'Energy diversification', 'Large domestic demand'],
    metrics: [
      { label: 'Investment Attractiveness', value: '89/100', change: '+4.1 YoY', source: 'Forecasta composite', updatedAt: '2026-03-08' },
      { label: 'Trade Momentum', value: '+6.7%', change: '12M growth', source: 'Trade monitor', updatedAt: '2026-03-08' },
      { label: 'Policy Agility', value: 'High', change: '5 reforms tracked', source: 'Policy tracker', updatedAt: '2026-03-08' }
    ]
  },
  {
    slug: 'singapore',
    name: 'Singapore',
    region: 'Asia',
    capital: 'Singapore',
    flag: '🇸🇬',
    summary: 'A global benchmark economy for ease of doing business, trade services, advanced technology, and headquarters strategy.',
    strengths: ['HQ hub', 'Deep capital markets', 'Advanced services', 'Stable policy environment'],
    metrics: [
      { label: 'Investment Attractiveness', value: '95/100', change: '+1.2 YoY', source: 'Forecasta composite', updatedAt: '2026-03-08' },
      { label: 'Trade Momentum', value: '+5.9%', change: '12M growth', source: 'Trade monitor', updatedAt: '2026-03-08' },
      { label: 'Policy Agility', value: 'High', change: '2 reforms tracked', source: 'Policy tracker', updatedAt: '2026-03-08' }
    ]
  }
];

export const sectors: Sector[] = [
  { slug: 'advanced-manufacturing', name: 'Advanced Manufacturing', description: 'High-value production, industrial technologies, and regional export platforms.', leaders: ['UAE', 'Saudi Arabia', 'Singapore'], outlook: 'Positive, driven by industrial policy, automation, and resilient supply chains.' },
  { slug: 'renewable-energy', name: 'Renewable Energy', description: 'Solar, wind, green hydrogen, storage, and grid innovation.', leaders: ['UAE', 'Saudi Arabia', 'Morocco'], outlook: 'Very strong medium-term pipeline linked to decarbonization and energy security.' },
  { slug: 'digital-economy', name: 'Digital Economy', description: 'AI, cloud, fintech, digital infrastructure, and advanced services.', leaders: ['Singapore', 'UAE', 'Estonia'], outlook: 'High-growth and policy-sensitive, with strong demand for talent and infrastructure.' }
];

export const companies: Company[] = [
  { slug: 'global-logix', name: 'Global Logix', country: 'United Arab Emirates', sector: 'Logistics', summary: 'Illustrative multinational logistics operator used for starter demos.', logo: 'GL' },
  { slug: 'nova-energy', name: 'Nova Energy', country: 'Saudi Arabia', sector: 'Renewable Energy', summary: 'Illustrative renewable energy developer with regional expansion story.', logo: 'NE' },
  { slug: 'quantum-fabrication', name: 'Quantum Fabrication', country: 'Singapore', sector: 'Advanced Manufacturing', summary: 'Illustrative industrial technology company with global footprint.', logo: 'QF' }
];

export const policies: Policy[] = [
  { title: 'Foreign Ownership Reform Package', country: 'United Arab Emirates', type: 'Investment Law', effectiveDate: '2025-11-01', summary: 'Illustrative package to demonstrate policy timeline and summary blocks.' },
  { title: 'Advanced Industry Incentives Program', country: 'Saudi Arabia', type: 'Sector Incentive', effectiveDate: '2025-09-18', summary: 'Illustrative sector-based incentive framework to support high-value manufacturing.' },
  { title: 'Digital Economy Expansion Strategy', country: 'Singapore', type: 'National Strategy', effectiveDate: '2026-01-05', summary: 'Illustrative strategic program focused on AI, cloud, talent, and global headquarters growth.' }
];

export const publications: Publication[] = [
  { title: 'Global Investment Outlook 2026', publisher: 'Forecasta Observatory', year: 2026, country: 'Global', sector: 'Cross-sector' },
  { title: 'UAE Logistics Competitiveness Brief', publisher: 'Forecasta Observatory', year: 2026, country: 'United Arab Emirates', sector: 'Logistics' },
  { title: 'Green Industry Benchmarking Pack', publisher: 'Forecasta Observatory', year: 2026, country: 'Global', sector: 'Renewable Energy' }
];
