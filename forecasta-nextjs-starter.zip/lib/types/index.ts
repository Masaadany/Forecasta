export type Kpi = { label: string; value: string; change: string; source: string; updatedAt: string; };
export type Country = {
  slug: string; name: string; region: string; capital: string; flag: string; summary: string;
  metrics: Kpi[];
  strengths: string[];
};
export type Sector = { slug: string; name: string; description: string; leaders: string[]; outlook: string; };
export type Company = { slug: string; name: string; country: string; sector: string; summary: string; logo: string; };
export type Policy = { title: string; country: string; type: string; effectiveDate: string; summary: string; };
export type Publication = { title: string; publisher: string; year: number; country: string; sector: string; }; 
