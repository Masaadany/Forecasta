# Forecasta — Full Next.js Starter Package

Forecasta is a futuristic global investment and trade intelligence platform starter built with Next.js App Router and TypeScript.

## Included stages
- Stage 1: Vision, architecture, and product structure
- Stage 2: Premium front-end starter and mock APIs
- Stage 3: Database schema draft
- Stage 4: Expansion hooks for live data, forecasting, and report generation

## Run locally
```bash
npm install
npm run dev
```

## Initial routes
- /
- /dashboard
- /countries/united-arab-emirates
- /sectors/advanced-manufacturing
- /companies/global-logix
- /opportunities
- /benchmarking
- /forecasts
- /reports
- /publications
- /advisory
- /about
- /methodology

## API starter endpoints
- /api/dashboard
- /api/countries
- /api/countries/united-arab-emirates
- /api/sectors/advanced-manufacturing
- /api/companies/global-logix
- /api/policies
- /api/incentives
- /api/benchmarking/compare
- /api/forecasts
- /api/publications

## Advisory note
This package uses illustrative content and placeholders where licensed data, logos, and advanced 3D assets would normally be integrated.
