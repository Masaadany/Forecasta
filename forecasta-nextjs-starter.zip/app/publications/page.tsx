import { GenericPage } from '@/components/ui/generic-page';

export default function PublicationsPage() {
  return <GenericPage badge="Publications Observatory" title="A searchable knowledge layer for reports, briefs, strategies, and sector intelligence." description="The publications database is designed to organize public reports from international organizations, governments, companies, and think tanks." highlights={["Search & Filters", "AI Summaries", "Citation Metadata", "Country Tags", "Sector Tags", "Related Content"]} />;
}
