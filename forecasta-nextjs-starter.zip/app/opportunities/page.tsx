import { PageHero } from '@/components/ui/page-hero';
import { GlobeHero } from '@/components/globe/globe-hero';

export default function OpportunitiesPage() {
  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge="Opportunities Map" title="3D geospatial exploration of investment opportunities, clusters, and corridors." description="The opportunities layer is designed to visualize where demand, incentives, infrastructure, and sector momentum align." />
      <GlobeHero />
    </div>
  );
}
