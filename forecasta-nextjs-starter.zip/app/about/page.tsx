import { GenericPage } from '@/components/ui/generic-page';

export default function AboutPage() {
  return <GenericPage badge="About Forecasta" title="Vision, mission, objectives, and platform promise." description="Forecasta is designed as a decision-support ecosystem that combines trusted data, strategic analytics, and future-oriented intelligence." highlights={["Vision & Mission", "Strategic Objectives", "Value Proposition", "Target Users", "Growth Roadmap", "Brand Narrative"]} />;
}
