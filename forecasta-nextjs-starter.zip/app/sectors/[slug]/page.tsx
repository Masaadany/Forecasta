import { notFound } from 'next/navigation';
import { sectors } from '@/lib/mock/data';
import { PageHero } from '@/components/ui/page-hero';

export default async function SectorPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const sector = sectors.find((item) => item.slug === slug);
  if (!sector) return notFound();

  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge="Sector Intelligence" title={sector.name} description={sector.description} />
      <section className="grid grid-2">
        <article className="card pad">
          <div className="badge">Sector Outlook</div>
          <p className="section-subtitle" style={{ marginTop: 12 }}>{sector.outlook}</p>
        </article>
        <article className="card pad">
          <div className="badge">Leading Markets</div>
          <div className="grid" style={{ marginTop: 12 }}>
            {sector.leaders.map((leader) => <div key={leader} className="stat-row"><strong>{leader}</strong></div>)}
          </div>
        </article>
      </section>
    </div>
  );
}
