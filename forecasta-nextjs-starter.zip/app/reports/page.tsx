import { GenericPage } from '@/components/ui/generic-page';

export default function ReportsPage() {
  return <GenericPage badge="Custom Report Generator" title="Generate tailored executive reports by country, city, sector, or investor theme." description="The report module is positioned as a premium revenue engine for rapid intelligence briefs and bespoke analytical outputs." highlights={["Input Wizard", "Benchmark Selection", "Forecast Scenarios", "Policy Analysis", "Executive Summary", "Advisory Upsell"]} />;
}
