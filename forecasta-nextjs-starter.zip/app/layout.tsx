import './globals.css';
import type { Metadata } from 'next';
import { SiteHeader } from '@/components/navigation/site-header';
import { SiteFooter } from '@/components/layout/site-footer';

export const metadata: Metadata = {
  title: 'Forecasta — Global Investment & Trade Platform',
  description: 'Futuristic global intelligence platform for investment, trade, policy, incentives, benchmarking, and forecasting.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <SiteHeader />
        <main className="page-shell">
          <div className="container">{children}</div>
        </main>
        <SiteFooter />
      </body>
    </html>
  );
}
