import { GenericPage } from '@/components/ui/generic-page';

export default function MethodologyPage() {
  return <GenericPage badge="Methodology" title="Trust framework, update logic, and forecasting governance." description="Every data point should be traceable to source, timestamp, frequency, definition, and confidence label." highlights={["Source Registry", "Data Freshness Labels", "Official vs Private Data Logic", "Validation Rules", "Forecast Assumptions", "Confidence Labels"]} />;
}
