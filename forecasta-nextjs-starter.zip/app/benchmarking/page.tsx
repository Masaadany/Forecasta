import { PageHero } from '@/components/ui/page-hero';

const peers = [
  ['United Arab Emirates', '92', 'High logistics competitiveness'],
  ['Saudi Arabia', '89', 'Large-scale transformation momentum'],
  ['Singapore', '95', 'Global benchmark for business environment']
];

export default function BenchmarkingPage() {
  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge="Benchmarking" title="Compare countries, cities, sectors, and institutional competitiveness." description="Benchmarking is designed to evaluate relative positioning, performance gaps, and strategic priorities through scorecards, heatmaps, and narrative insight." />
      <section className="card pad">
        <table className="table">
          <thead>
            <tr><th>Peer</th><th>Composite Score</th><th>Strategic Note</th></tr>
          </thead>
          <tbody>
            {peers.map(([name, score, note]) => (
              <tr key={name}><td>{name}</td><td>{score}/100</td><td>{note}</td></tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
