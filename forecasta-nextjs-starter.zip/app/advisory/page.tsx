import { GenericPage } from '@/components/ui/generic-page';

export default function AdvisoryPage() {
  return <GenericPage badge="Advisory Services" title="Translate intelligence into strategy, policy, and investor action." description="Forecasta supports advisory conversion through market studies, investment strategies, IPA assessments, benchmarking, and foresight assignments." highlights={["Market Studies", "Investment Strategies", "Policy Reviews", "IPA Performance Assessment", "Investor Targeting", "Scenario Planning Labs"]} />;
}
