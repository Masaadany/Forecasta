import Link from 'next/link';
import { GlobeHero } from '@/components/globe/globe-hero';
import { KpiGrid } from '@/components/dashboard/kpi-grid';
import { countries, companies, policies, publications, sectors } from '@/lib/mock/data';
import { LogoTile } from '@/components/ui/logo-tile';

export default function HomePage() {
  return (
    <div className="grid" style={{ gap: 32 }}>
      <section className="hero">
        <div className="card hero-copy">
          <div className="badge">Forecasta · Global Investment & Trade Platform</div>
          <h1 className="section-title">A futuristic 3D intelligence platform for investment, trade, policy, benchmarking, and foresight.</h1>
          <p className="section-subtitle">
            Forecasta is designed for decision-makers, investors, governments, IPAs, and researchers seeking verified intelligence, comparative analytics, source-linked evidence, and forward-looking scenario planning in one premium digital ecosystem.
          </p>
          <div className="hero-actions">
            <Link href="/dashboard" className="btn primary">Open Global Dashboard</Link>
            <Link href="/reports" className="btn secondary">Launch Report Generator</Link>
            <Link href="/methodology" className="btn secondary">View Trust Framework</Link>
          </div>
          <div className="grid grid-3" style={{ marginTop: 28 }}>
            <div className="card pad">
              <div className="tiny">Core Promise</div>
              <div style={{ fontWeight: 700, marginTop: 6 }}>Source-first intelligence</div>
            </div>
            <div className="card pad">
              <div className="tiny">Coverage</div>
              <div style={{ fontWeight: 700, marginTop: 6 }}>Country · City · Sector · Company</div>
            </div>
            <div className="card pad">
              <div className="tiny">Experience</div>
              <div style={{ fontWeight: 700, marginTop: 6 }}>3D map-led exploration</div>
            </div>
          </div>
        </div>
        <GlobeHero />
      </section>

      <KpiGrid />

      <section className="grid grid-3">
        <article className="card pad">
          <div className="badge">Vision</div>
          <h2>Trusted global intelligence</h2>
          <p className="muted">Build the world’s most trusted platform for investment and trade decision support, combining verified data, policy tracking, analytics, and foresight.</p>
        </article>
        <article className="card pad">
          <div className="badge">Mission</div>
          <h2>Unify fragmented sources</h2>
          <p className="muted">Transform fragmented macro, investment, trade, company, and policy information into a coherent intelligence ecosystem with transparent sourcing.</p>
        </article>
        <article className="card pad">
          <div className="badge">Objectives</div>
          <h2>Support action and strategy</h2>
          <p className="muted">Enable benchmarking, investor targeting, policy reviews, sector prioritization, and scenario planning for governments and investors.</p>
        </article>
      </section>

      <section className="grid grid-2">
        <article className="card pad">
          <div className="badge">Featured Economies</div>
          <div className="grid" style={{ marginTop: 16 }}>
            {countries.map((country) => (
              <Link key={country.slug} href={`/countries/${country.slug}`} className="stat-row">
                <div>
                  <div style={{ fontWeight: 700 }}>{country.flag} {country.name}</div>
                  <div className="tiny">{country.region} · {country.capital}</div>
                </div>
                <span className="muted">View profile →</span>
              </Link>
            ))}
          </div>
        </article>
        <article className="card pad">
          <div className="badge">Priority Sectors</div>
          <div className="grid" style={{ marginTop: 16 }}>
            {sectors.map((sector) => (
              <Link key={sector.slug} href={`/sectors/${sector.slug}`} className="stat-row">
                <div>
                  <div style={{ fontWeight: 700 }}>{sector.name}</div>
                  <div className="tiny">{sector.outlook}</div>
                </div>
                <span className="muted">Explore →</span>
              </Link>
            ))}
          </div>
        </article>
      </section>

      <section className="grid grid-2">
        <article className="card pad">
          <div className="badge">Recent Policy Signals</div>
          <div className="grid" style={{ marginTop: 16 }}>
            {policies.map((policy) => (
              <div key={policy.title} className="stat-row">
                <div>
                  <div style={{ fontWeight: 700 }}>{policy.title}</div>
                  <div className="tiny">{policy.country} · {policy.type} · Effective {policy.effectiveDate}</div>
                </div>
              </div>
            ))}
          </div>
        </article>
        <article className="card pad">
          <div className="badge">Latest Publications</div>
          <div className="grid" style={{ marginTop: 16 }}>
            {publications.map((publication) => (
              <div key={publication.title} className="stat-row">
                <div>
                  <div style={{ fontWeight: 700 }}>{publication.title}</div>
                  <div className="tiny">{publication.publisher} · {publication.year} · {publication.sector}</div>
                </div>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="card pad">
        <div className="page-header">
          <div>
            <div className="badge">Illustrative Companies & Entities</div>
            <h2 style={{ marginBottom: 8 }}>Company logos, source marks, and ecosystem entities</h2>
            <p className="section-subtitle">The starter package uses illustrative placeholders to demonstrate the visual structure for company and ecosystem cards.</p>
          </div>
        </div>
        <div className="logo-strip">
          {companies.map((company) => (
            <LogoTile key={company.slug} title={company.name} subtitle={`${company.country} · ${company.sector}`} mark={company.logo} />
          ))}
          <LogoTile title="Official Sources" subtitle="World Bank · IMF · OECD · WTO" mark="OS" />
          <LogoTile title="Policy Monitor" subtitle="Legal & strategy tracking" mark="PM" />
          <LogoTile title="Forecast Engine" subtitle="Baseline · upside · downside" mark="FE" />
        </div>
      </section>
    </div>
  );
}
