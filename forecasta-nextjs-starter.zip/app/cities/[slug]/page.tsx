import { GenericPage } from '@/components/ui/generic-page';

export default function CityPage() {
  return <GenericPage badge="City Profile" title="City intelligence page starter." description="City pages will be used for clusters, infrastructure, opportunities, costs, and sector strengths." highlights={["Economic Snapshot", "Cluster Map", "Procedures", "Incentives", "Leading Sectors", "Investor Footprint"]} />;
}
