import { PageHero } from '@/components/ui/page-hero';
import { KpiGrid } from '@/components/dashboard/kpi-grid';
import { countries, sectors } from '@/lib/mock/data';

export default function DashboardPage() {
  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge="Global Dashboard" title="Live-style investment and trade intelligence cockpit." description="A dashboard designed for source-linked KPIs, sector signals, benchmark comparisons, and map-led exploration." />
      <div className="filters">
        {['All Regions', 'All Sectors', 'Official Sources', 'Latest 12M', 'Country/Corridor Mode'].map((f) => <span key={f} className="filter-pill">{f}</span>)}
      </div>
      <KpiGrid />
      <section className="grid grid-2">
        <article className="card pad">
          <div className="badge">Featured Economies</div>
          {countries.map((country) => (
            <div key={country.slug} className="stat-row">
              <div>
                <div style={{ fontWeight: 700 }}>{country.flag} {country.name}</div>
                <div className="tiny">{country.summary}</div>
              </div>
            </div>
          ))}
        </article>
        <article className="card pad">
          <div className="badge">Sector Momentum</div>
          {sectors.map((sector, index) => (
            <div key={sector.slug} style={{ padding: '12px 0' }}>
              <div className="stat-row" style={{ borderBottom: 'none', paddingBottom: 8 }}>
                <strong>{sector.name}</strong>
                <span className="tiny">Trend score {88 - index * 5}/100</span>
              </div>
              <div className="progress"><span style={{ width: `${88 - index * 5}%` }} /></div>
            </div>
          ))}
        </article>
      </section>
    </div>
  );
}
