import { notFound } from 'next/navigation';
import { countries } from '@/lib/mock/data';
import { PageHero } from '@/components/ui/page-hero';

export default async function CountryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const country = countries.find((item) => item.slug === slug);
  if (!country) return notFound();

  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge={`${country.flag} Country Profile`} title={country.name} description={country.summary} />
      <section className="grid grid-3">
        {country.metrics.map((metric) => (
          <article key={metric.label} className="card pad">
            <div className="tiny">{metric.label}</div>
            <div className="kpi">{metric.value}</div>
            <div className="muted">{metric.change}</div>
            <div className="tiny">{metric.source} · {metric.updatedAt}</div>
          </article>
        ))}
      </section>
      <section className="card pad">
        <div className="badge">Strategic Strengths</div>
        <div className="grid grid-2" style={{ marginTop: 16 }}>
          {country.strengths.map((strength) => (
            <div key={strength} className="card pad">{strength}</div>
          ))}
        </div>
      </section>
    </div>
  );
}
