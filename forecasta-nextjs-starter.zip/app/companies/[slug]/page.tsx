import { notFound } from 'next/navigation';
import { companies } from '@/lib/mock/data';
import { PageHero } from '@/components/ui/page-hero';

export default async function CompanyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const company = companies.find((item) => item.slug === slug);
  if (!company) return notFound();

  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge="Company Intelligence" title={company.name} description={company.summary} />
      <section className="card pad" style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
        <div style={{ width: 80, height: 80, borderRadius: 24, background: 'rgba(255,255,255,0.08)', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 24 }}>{company.logo}</div>
        <div>
          <div className="tiny">Headquarters</div>
          <div style={{ fontWeight: 700 }}>{company.country}</div>
          <div className="tiny">Sector: {company.sector}</div>
        </div>
      </section>
    </div>
  );
}
