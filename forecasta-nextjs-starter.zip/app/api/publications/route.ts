import { NextResponse } from 'next/server';
import { publications } from '@/lib/mock/data';

export async function GET() {
  return NextResponse.json({ data: publications });
}
