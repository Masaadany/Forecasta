import { NextResponse } from 'next/server';

export async function GET(_: Request, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  return NextResponse.json({ data: { slug, message: 'City API starter endpoint.' } });
}
