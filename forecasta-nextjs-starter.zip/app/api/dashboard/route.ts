import { NextResponse } from 'next/server';
import { headlineKpis } from '@/lib/mock/data';

export async function GET() {
  return NextResponse.json({ data: headlineKpis, generatedAt: new Date().toISOString() });
}
