import { NextResponse } from 'next/server';
import { companies } from '@/lib/mock/data';

export async function GET(_: Request, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = companies.find((item) => item.slug === slug);
  if (!company) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ data: company });
}
