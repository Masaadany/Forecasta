import { NextResponse } from 'next/server';
import { countries } from '@/lib/mock/data';

export async function GET(_: Request, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const country = countries.find((item) => item.slug === slug);
  if (!country) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ data: country });
}
