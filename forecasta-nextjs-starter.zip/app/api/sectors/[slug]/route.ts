import { NextResponse } from 'next/server';
import { sectors } from '@/lib/mock/data';

export async function GET(_: Request, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const sector = sectors.find((item) => item.slug === slug);
  if (!sector) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ data: sector });
}
