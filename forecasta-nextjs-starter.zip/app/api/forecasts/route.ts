import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({ data: [{ scenario: 'Baseline', value: 100, lowerBound: 94, upperBound: 108 }] });
}
