import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({ data: [{ name: 'Illustrative R&D Incentive', country: 'United Arab Emirates', type: 'Financial' }] });
}
