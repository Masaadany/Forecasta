import { NextResponse } from 'next/server';
import { policies } from '@/lib/mock/data';

export async function GET() {
  return NextResponse.json({ data: policies });
}
