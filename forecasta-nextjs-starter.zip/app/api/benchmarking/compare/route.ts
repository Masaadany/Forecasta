import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({ data: [{ entity: 'United Arab Emirates', score: 92 }, { entity: 'Saudi Arabia', score: 89 }, { entity: 'Singapore', score: 95 }] });
}
