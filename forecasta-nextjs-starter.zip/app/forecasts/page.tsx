import { PageHero } from '@/components/ui/page-hero';

const scenarios = [
  ['Baseline', 'Stable reform momentum and moderate external demand.'],
  ['Upside', 'Stronger policy execution, logistics gains, and sector acceleration.'],
  ['Downside', 'Global demand weakness, higher risk perception, and corridor disruption.']
];

export default function ForecastsPage() {
  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero badge="Forecast Studio" title="Predictive analytics and scenario planning with visible assumptions." description="Forecast outputs should always be linked to model version, assumptions, confidence range, and source-backed input variables." />
      <section className="grid grid-3">
        {scenarios.map(([title, text], index) => (
          <article key={title} className="card pad">
            <div className="badge">Scenario {index + 1}</div>
            <h3>{title}</h3>
            <p className="muted">{text}</p>
            <div className="progress"><span style={{ width: `${70 + index * 10}%` }} /></div>
          </article>
        ))}
      </section>
    </div>
  );
}
