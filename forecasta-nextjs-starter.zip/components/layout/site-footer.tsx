export function SiteFooter() {
  return (
    <footer className="footer">
      <div className="container grid grid-3">
        <div>
          <strong>Forecasta</strong>
          <p className="muted">Futuristic intelligence portal for global investment, trade, policy, benchmarking, and foresight.</p>
        </div>
        <div>
          <strong>Trust Framework</strong>
          <p className="muted">Every metric is designed to display source, update timestamp, frequency, and methodology context.</p>
        </div>
        <div>
          <strong>Build Package</strong>
          <p className="muted">Starter Next.js package with app router, mock APIs, schema draft, and page architecture.</p>
        </div>
      </div>
    </footer>
  );
}
