import Link from 'next/link';
import { mainNavigation } from '@/lib/constants/navigation';

export function SiteHeader() {
  return (
    <header className="top-nav">
      <div className="container nav-inner">
        <Link href="/" className="brand" aria-label="Forecasta home">
          <span className="brand-mark" />
          <span>
            Forecasta
            <div className="tiny">Global Investment & Trade Platform</div>
          </span>
        </Link>
        <nav className="nav-links" aria-label="Primary navigation">
          {mainNavigation.map(([href, label]) => (
            <Link key={href} href={href} className="nav-link">
              {label}
            </Link>
          ))}
        </nav>
        <div style={{ display: 'flex', gap: 10 }}>
          <Link className="btn secondary" href="/methodology">Methodology</Link>
          <Link className="btn primary" href="/reports">Generate Report</Link>
        </div>
      </div>
    </header>
  );
}
