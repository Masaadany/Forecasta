import { headlineKpis } from '@/lib/mock/data';
import { SourceStamp } from '@/components/ui/source-stamp';

export function KpiGrid() {
  return (
    <div className="grid grid-4">
      {headlineKpis.map((item) => (
        <article key={item.label} className="card pad">
          <div className="tiny">{item.label}</div>
          <div className="kpi">{item.value}</div>
          <div className="muted">{item.change}</div>
          <div className="header-divider" />
          <div style={{ marginTop: 12 }}>
            <SourceStamp source={item.source} updatedAt={item.updatedAt} />
          </div>
        </article>
      ))}
    </div>
  );
}
