export function GlobeHero() {
  return (
    <div className="hero-globe card">
      <div className="flow-line" style={{ width: '44%', left: '13%', top: '42%', transform: 'rotate(-10deg)' }} />
      <div className="flow-line" style={{ width: '32%', right: '11%', top: '38%', transform: 'rotate(18deg)' }} />
      <div className="flow-line" style={{ width: '28%', left: '26%', top: '58%', transform: 'rotate(12deg)' }} />
      <div className="dot" style={{ left: '26%', top: '49%' }} />
      <div className="dot" style={{ left: '51%', top: '40%' }} />
      <div className="dot" style={{ right: '22%', top: '47%' }} />
      <div className="dot" style={{ left: '44%', top: '62%' }} />
      <div style={{ position: 'absolute', inset: 'auto 24px 24px 24px' }}>
        <div className="card pad">
          <div className="badge">3D Global Intelligence Canvas</div>
          <div className="grid grid-3" style={{ marginTop: 16 }}>
            <div>
              <div className="tiny">Mode</div>
              <div className="kpi" style={{ fontSize: 22 }}>Investment Flows</div>
            </div>
            <div>
              <div className="tiny">Layers</div>
              <div className="kpi" style={{ fontSize: 22 }}>Countries · Cities · Sectors</div>
            </div>
            <div>
              <div className="tiny">Display</div>
              <div className="kpi" style={{ fontSize: 22 }}>Futuristic 3D starter</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
