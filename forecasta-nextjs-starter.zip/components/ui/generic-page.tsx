import Link from 'next/link';
import { PageHero } from '@/components/ui/page-hero';

type GenericPageProps = {
  badge: string;
  title: string;
  description: string;
  highlights: string[];
};

export function GenericPage({ badge, title, description, highlights }: GenericPageProps) {
  return (
    <div className="grid" style={{ gap: 24 }}>
      <PageHero
        badge={badge}
        title={title}
        description={description}
        actions={<Link href="/reports" className="btn primary">Generate Custom Report</Link>}
      />
      <section className="grid grid-3">
        {highlights.map((highlight) => (
          <article key={highlight} className="card pad">
            <div className="badge">Module</div>
            <h3>{highlight}</h3>
            <p className="muted">Starter placeholder section prepared for Next.js expansion, API integration, and live-data binding.</p>
          </article>
        ))}
      </section>
      <section className="card pad">
        <div className="badge">Implementation Note</div>
        <p className="section-subtitle">This page is intentionally scaffolded with reusable design patterns so you can attach real services, controls, charts, and data layers in the next stage without restructuring the project.</p>
      </section>
    </div>
  );
}
