import { ReactNode } from 'react';

type PageHeroProps = {
  badge?: string;
  title: string;
  description: string;
  actions?: ReactNode;
};

export function PageHero({ badge, title, description, actions }: PageHeroProps) {
  return (
    <section className="page-header">
      <div>
        {badge ? <div className="badge">{badge}</div> : null}
        <h1 className="section-title">{title}</h1>
        <p className="section-subtitle" style={{ maxWidth: 820 }}>{description}</p>
      </div>
      {actions ? <div>{actions}</div> : null}
    </section>
  );
}
