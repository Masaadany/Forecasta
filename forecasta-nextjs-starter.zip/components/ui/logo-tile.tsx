type LogoTileProps = { title: string; subtitle: string; mark: string; };

export function LogoTile({ title, subtitle, mark }: LogoTileProps) {
  return (
    <div className="card pad" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{ width: 44, height: 44, borderRadius: 14, background: 'rgba(255,255,255,0.08)', display: 'grid', placeItems: 'center', fontWeight: 700 }}>
        {mark}
      </div>
      <div>
        <div>{title}</div>
        <div className="tiny">{subtitle}</div>
      </div>
    </div>
  );
}
