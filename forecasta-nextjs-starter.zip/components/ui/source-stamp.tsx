type SourceStampProps = {
  source: string;
  updatedAt: string;
};

export function SourceStamp({ source, updatedAt }: SourceStampProps) {
  return <div className="tiny">Source: {source} · Updated: {updatedAt}</div>;
}
